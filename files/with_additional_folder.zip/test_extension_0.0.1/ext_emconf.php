<?php

$EM_CONF[$_EXTKEY] = array (
	'title' => 'Test extension',
	'description' => 'A test extension by the T3o Team that is used for automated testing. It does not do anything useful, and just holds a dummy file. Check the README.',
	'category' => 'fe',
	'shy' => 0,
	'version' => '0.0.1',
	'dependencies' => '',
	'conflicts' => '',
	'priority' => '',
	'loadOrder' => '',
	'TYPO3_version' => '4.5.5-6.1.99',
	'PHP_version' => '5.3.0-0.0.0',
	'module' => '',
	'state' => 'beta',
	'uploadfolder' => 1,
	'constraints' => array(
		'depends' => array(
			'typo3' => '4.5.5-6.1.99',
			'extbase' => '',
			'fluid' => '',
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'createDirs' => '',
	'modify_tables' => '',
	'clearcacheonload' => 0,
	'lockType' => '',
	'author' => 'Christian Zenker',
	'author_email' => 'typo3@xopn.de',
	'author_company' => '',
	'CGLcompliance' => NULL,
	'CGLcompliance_note' => NULL,
);

?>